<?php
$conn = mysql_connect("127.0.0.1","root","123456") or die("Error " . mysql_error($conn));
mysql_select_db ( 'perdona' )
?>